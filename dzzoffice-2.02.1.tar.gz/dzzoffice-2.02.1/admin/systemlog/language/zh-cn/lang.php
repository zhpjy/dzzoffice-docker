<?php
$lang = array (
    'appname'=>'系统日志',
	'logs' => '运行记录',
    'systemlog_setting'=>'设置',
    'systemlog_list'=>'日志列表',
	'info'=>'信息',
	'loginfo'=>'日志信息',
	'visit'=>'访问页面',
	'from'=>'来源页面',
	'logswitch'=>'日志开关',
	'logtype'=>'日志类型',
	'logtypename'=>'日志类型名称',
	'logtype'=>'日志类型',
	'logflag'=>'日志标识',
	
);

?>